# PyGitrefer: Your GitHub-Powered Bibliography Manager!

📚 Welcome to PyGitrefer, your friendly companion for effortlessly managing bibliographic information directly within your GitHub repositories! Say goodbye to messy spreadsheets and hello to a streamlined, version-controlled, and collaborative approach to keeping your research references in order.

## What is PyGitrefer?

PyGitrefer is a Python package designed to make managing your references on GitHub a breeze. It allows you to:

* **Add References:** Easily add new references from DOIs or PDFs, even extracting information automatically.
* **Organize with Tags:** Categorize your references with custom tags for quick filtering and searching.
* **Attach Files:** Link PDFs, notes, or any relevant files directly to your references.
* **Export in Multiple Formats:** Generate citations in BibTeX, APA, RIS, and more!
* **Version Control:** Leverage the power of Git to track changes and collaborate with others.
* **User-Friendly CLI:** Interact with PyGitrefer using a simple and intuitive command-line interface.

## Getting Started

### Installation

1. **Install using pip:**

   ```bash
   pip install PyGitrefer
   ```

### Configuration

1. **GitHub Personal Access Token:**
   - Generate a personal access token on GitHub with `repo` scope.
   - Store your token securely (e.g., in an environment variable or a configuration file).

2. **Repository Information:**
   - Determine the owner and name of your GitHub repository (e.g., `your-username/your-repository`).

### Usage

1. **List All References:**

   ```bash
   gitrefer list
   ```

2. **Show Reference Details:**

   ```bash
   gitrefer show <ID>
   ```

3. **Add Reference from DOI:**

   ```bash
   gitrefer add_doi <DOI>
   ```

4. **Add Reference from PDF:**

   ```bash
   gitrefer add_pdf <path/to/pdf>
   ```

5. **Add Reference Manually:**

   ```bash
   gitrefer add_manual
   ```

6. **Find New References:**

   ```bash
   gitrefer find_new
   ```

7. **Update Reference:**

   ```bash
   gitrefer update <old_ID> <new_ID> 
   ```

8. **Delete Reference:**

   ```bash
   gitrefer delete <ID>
   ```

9. **Add Tag:**

   ```bash
   gitrefer add_tag <ID> <tag>
   ```

10. **Remove Tag:**

    ```bash
    gitrefer remove_tag <ID> <tag>
    ```

11. **Add File:**

    ```bash
    gitrefer add_file <ID> <path/to/file>
    ```

12. **Delete File:**

    ```bash
    gitrefer delete_file <ID> <filename>
    ```

13. **Export References:**

    ```bash
    gitrefer export <format> [-t <tag>]
    ```

14. **Reset References:**

    ```bash
    gitrefer reset
    ```

**For more detailed information and advanced usage, please refer to the [documentation](link-to-docs).**

## Why Use PyGitrefer?

* **Collaboration Made Easy:** Work seamlessly with colleagues on shared research projects.
* **Version Control:** Track changes to your references over time, ensuring data integrity.
* **Organization and Efficiency:** Keep your references neatly organized and easily accessible.
* **Integration with GitHub:** Leverage the familiar and powerful platform of GitHub.

## Contributing

We welcome contributions from the community! If you'd like to contribute to PyGitrefer, please check out our [contribution guidelines](link-to-contribution-guidelines).

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

---

Happy referencing! Let PyGitrefer be your trusted guide in the world of academic literature. 🚀